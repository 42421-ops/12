import { motion } from 'framer-motion';
import { Clock, CalendarX } from 'lucide-react';
import { generateTimeSlots } from '@/utils/date';
import type { Booking } from '@/types';

interface TimeSlotsProps {
  dateISO: string;
  bookings: Booking[];
  selectedTime: string | null;
  onSelect: (time: string) => void;
}

export function TimeSlots({ dateISO, bookings, selectedTime, onSelect }: TimeSlotsProps) {
  const allSlots = generateTimeSlots();
  const takenSlots = new Set(
    bookings
      .filter((b) => b.date === dateISO && b.status !== 'cancelled')
      .map((b) => b.time),
  );

  const freeSlots = allSlots.filter((s) => !takenSlots.has(s));

  if (freeSlots.length === 0) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass rounded-2xl p-8 text-center"
      >
        <CalendarX className="h-10 w-10 text-zinc-500 mx-auto mb-3" />
        <p className="text-sm font-medium text-zinc-300">На эту дату всё занято</p>
        <p className="text-xs text-zinc-500 mt-1">Выберите другую дату</p>
      </motion.div>
    );
  }

  return (
    <div className="grid grid-cols-4 gap-2">
      {allSlots.map((time, idx) => {
        const isTaken = takenSlots.has(time);
        const isSelected = selectedTime === time;
        return (
          <motion.button
            key={time}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.2, delay: idx * 0.02 }}
            whileTap={!isTaken ? { scale: 0.95 } : undefined}
            disabled={isTaken}
            onClick={() => !isTaken && onSelect(time)}
            className={`relative rounded-xl py-2.5 text-sm font-medium transition-all ${
              isSelected
                ? 'bg-accent-gradient text-[#0A0A0B] shadow-glow'
                : isTaken
                  ? 'bg-white/[0.02] text-zinc-600 line-through cursor-not-allowed'
                  : 'glass text-zinc-200 hover:bg-white/[0.08]'
            }`}
          >
            {time}
          </motion.button>
        );
      })}
    </div>
  );
}
