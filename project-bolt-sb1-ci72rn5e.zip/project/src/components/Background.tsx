export function Background() {
  return (
    <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
      {/* Base */}
      <div className="absolute inset-0 bg-[#0A0A0B] dark:bg-[#0A0A0B] light:bg-gray-50" />

      {/* Gradient blobs */}
      <div className="absolute -top-24 -left-24 h-96 w-96 rounded-full bg-accent-cyan/20 blur-[120px]" />
      <div className="absolute top-1/3 -right-32 h-[28rem] w-[28rem] rounded-full bg-accent-green/15 blur-[140px]" />
      <div className="absolute bottom-0 left-1/4 h-80 w-80 rounded-full bg-accent-cyan/10 blur-[100px]" />

      {/* Noise overlay */}
      <div className="absolute inset-0 noise opacity-[0.015] dark:opacity-[0.015] light:opacity-[0.02]" />
    </div>
  );
}
