/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        sans: ['Manrope', 'Inter', 'system-ui', 'sans-serif'],
      },
      colors: {
        accent: {
          cyan: '#00E0FF',
          green: '#00FFB2',
        },
        surface: {
          50: '#18181B',
          100: '#1C1C20',
          200: '#222227',
        },
      },
      backgroundImage: {
        'accent-gradient': 'linear-gradient(135deg, #00E0FF 0%, #00FFB2 100%)',
        'accent-gradient-hover': 'linear-gradient(135deg, #00C8E6 0%, #00E6A3 100%)',
      },
      boxShadow: {
        glow: '0 0 24px -4px rgba(0, 224, 255, 0.4)',
        'glow-lg': '0 0 40px -8px rgba(0, 224, 255, 0.5)',
      },
      animation: {
        'fade-in': 'fadeIn 0.4s ease-out',
        'slide-up': 'slideUp 0.5s ease-out',
        'pulse-glow': 'pulseGlow 2s ease-in-out infinite',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { opacity: '0', transform: 'translateY(16px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        pulseGlow: {
          '0%, 100%': { boxShadow: '0 0 24px -4px rgba(0, 224, 255, 0.4)' },
          '50%': { boxShadow: '0 0 36px -4px rgba(0, 255, 178, 0.6)' },
        },
      },
    },
  },
  plugins: [],
};
