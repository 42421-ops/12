import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Check, MoreVertical, Phone, Car, Clock, Calendar, Trash2 } from 'lucide-react';
import type { Booking, BookingStatus } from '@/types';
import { STATUS_LABELS, STATUS_ORDER } from '@/constants/services';
import { formatPhoneDisplay } from '@/utils/booking';
import { parseISODate, formatFullDate } from '@/utils/date';

interface BookingCardProps {
  booking: Booking;
  onStatusChange: (id: string, status: BookingStatus) => void;
  onDelete: (id: string) => void;
}

export function BookingCard({ booking, onStatusChange, onDelete }: BookingCardProps) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!menuOpen) return;
    const handler = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [menuOpen]);

  const status = STATUS_LABELS[booking.status];

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.25 }}
      className="glass rounded-2xl p-4 relative"
    >
      <div className="flex items-start justify-between gap-2 mb-3">
        <div className="flex-1 min-w-0">
          <h4 className="font-semibold text-sm truncate">{booking.customerName}</h4>
          <div className="flex items-center gap-1.5 mt-1">
            <span className={`badge ${status.color}`}>
              <span className={`h-1.5 w-1.5 rounded-full ${status.dot}`} />
              {status.label}
            </span>
          </div>
        </div>

        <div className="relative" ref={menuRef}>
          <button
            onClick={() => setMenuOpen((v) => !v)}
            className="p-2 rounded-xl hover:bg-white/10 transition-colors"
          >
            <MoreVertical className="h-4 w-4 text-zinc-400" />
          </button>
          <AnimatePresence>
            {menuOpen && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95, y: -8 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: -8 }}
                transition={{ duration: 0.15 }}
                className="absolute right-0 top-full mt-1 z-20 glass-strong rounded-xl p-1.5 min-w-[160px] shadow-2xl"
              >
                <p className="px-2.5 py-1.5 text-[10px] text-zinc-500 uppercase tracking-wide font-medium">
                  Статус
                </p>
                {STATUS_ORDER.map((s) => {
                  const meta = STATUS_LABELS[s];
                  const isCurrent = booking.status === s;
                  return (
                    <button
                      key={s}
                      onClick={() => {
                        onStatusChange(booking.id, s);
                        setMenuOpen(false);
                      }}
                      className="w-full flex items-center justify-between px-2.5 py-2 rounded-lg hover:bg-white/10 transition-colors text-left"
                    >
                      <span className="flex items-center gap-2 text-sm">
                        <span className={`h-1.5 w-1.5 rounded-full ${meta.dot}`} />
                        {meta.label}
                      </span>
                      {isCurrent && <Check className="h-3.5 w-3.5 text-accent-cyan" />}
                    </button>
                  );
                })}
                <div className="h-px bg-white/10 my-1.5" />
                <button
                  onClick={() => {
                    setConfirmDelete(true);
                    setMenuOpen(false);
                  }}
                  className="w-full flex items-center gap-2 px-2.5 py-2 rounded-lg hover:bg-red-500/10 transition-colors text-left text-sm text-red-400"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  Удалить
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Details */}
      <div className="space-y-2">
        <DetailRow icon={Phone} text={formatPhoneDisplay(booking.customerPhone)} href={`tel:${booking.customerPhone.replace(/\D/g, '')}`} />
        <DetailRow icon={Car} text={booking.carModel} />
        <DetailRow icon={Calendar} text={formatFullDate(parseISODate(booking.date))} />
        <DetailRow icon={Clock} text={`${booking.time} · ${booking.serviceName}`} />
      </div>

      {/* Delete confirmation */}
      <AnimatePresence>
        {confirmDelete && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-10 glass-strong rounded-2xl flex flex-col items-center justify-center p-4"
          >
            <Trash2 className="h-8 w-8 text-red-400 mb-2" />
            <p className="text-sm text-zinc-200 text-center mb-1">Удалить запись?</p>
            <p className="text-xs text-zinc-500 text-center mb-4">{booking.customerName} · {booking.serviceName}</p>
            <div className="flex gap-2 w-full">
              <button onClick={() => setConfirmDelete(false)} className="btn-secondary flex-1 text-xs py-2.5">
                Отмена
              </button>
              <button
                onClick={() => onDelete(booking.id)}
                className="btn-danger flex-1 text-xs py-2.5"
              >
                Удалить
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

function DetailRow({ icon: Icon, text, href }: { icon: typeof Phone; text: string; href?: string }) {
  const content = (
    <div className="flex items-center gap-2.5 text-xs text-zinc-400">
      <Icon className="h-3.5 w-3.5 text-zinc-500 shrink-0" />
      <span className="truncate">{text}</span>
    </div>
  );
  if (href) {
    return (
      <a href={href} className="hover:text-accent-cyan transition-colors block">
        {content}
      </a>
    );
  }
  return content;
}
