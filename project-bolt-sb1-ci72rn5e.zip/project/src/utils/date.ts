import { format, addDays, isToday, isTomorrow, isSameDay } from 'date-fns';
import { ru } from 'date-fns/locale';

export function formatDateLabel(date: Date): string {
  if (isToday(date)) return 'Сегодня';
  if (isTomorrow(date)) return 'Завтра';
  return format(date, 'd MMM', { locale: ru });
}

export function formatFullDate(date: Date): string {
  return format(date, 'd MMMM, EEEE', { locale: ru });
}

export function formatDateISO(date: Date): string {
  return format(date, 'yyyy-MM-dd');
}

export function parseISODate(iso: string): Date {
  // Parse as local date (not UTC) to avoid timezone drift
  const [y, m, d] = iso.split('-').map(Number);
  return new Date(y, m - 1, d);
}

export function getNextDays(count: number): Date[] {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return Array.from({ length: count }, (_, i) => addDays(today, i));
}

export function getDayShort(date: Date): string {
  return format(date, 'EE', { locale: ru });
}

export function getDayNumber(date: Date): string {
  return format(date, 'd');
}

export function isSameDate(a: string, b: string): boolean {
  return a === b;
}

export function generateTimeSlots(): string[] {
  const slots: string[] = [];
  for (let h = 9; h < 21; h++) {
    slots.push(`${String(h).padStart(2, '0')}:00`);
    slots.push(`${String(h).padStart(2, '0')}:30`);
  }
  return slots;
}

export function formatPrice(price: number): string {
  return `${price.toLocaleString('ru-RU')} ₽`;
}

export function formatDuration(minutes: number): string {
  if (minutes < 60) return `${minutes} мин`;
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return m === 0 ? `${h} ч` : `${h} ч ${m} мин`;
}

export { isSameDay, isToday, isTomorrow, format, addDays };
