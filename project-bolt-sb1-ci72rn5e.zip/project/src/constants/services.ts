import type { Service } from '@/types';

export const SERVICES: Service[] = [
  {
    id: 'express',
    name: 'Экспресс-мойка',
    description: 'Быстрая мойка кузова, сушка, протирка стёкол',
    price: 500,
    duration: 20,
    icon: 'Zap',
  },
  {
    id: 'complex',
    name: 'Комплекс (кузов + салон)',
    description: 'Мойка кузова, уборка салона, полировка пластика',
    price: 1200,
    duration: 60,
    icon: 'Sparkles',
  },
  {
    id: 'dry-cleaning',
    name: 'Химчистка салона',
    description: 'Глубокая чистка сидений, потолка, ковриков, дверных карт',
    price: 3500,
    duration: 180,
    icon: 'Droplets',
  },
  {
    id: 'tire-blacking',
    name: 'Чернение шин',
    description: 'Нанесение чернителя — насыщенный чёрный цвет и блеск',
    price: 300,
    duration: 15,
    icon: 'CircleDot',
  },
  {
    id: 'wax',
    name: 'Воск (защитное покрытие)',
    description: 'Защитный слой, гидрофобный эффект, блеск кузова',
    price: 600,
    duration: 30,
    icon: 'Shield',
  },
];

export const ADMIN_PIN = '1234';

export const WORKING_HOURS = {
  start: 9,
  end: 21,
  step: 30, // minutes
};

export const DAYS_AHEAD = 14;

export const STATUS_LABELS: Record<string, { label: string; color: string; dot: string }> = {
  new: { label: 'Новая', color: 'text-blue-400 bg-blue-500/10 border border-blue-500/30', dot: 'bg-blue-400' },
  confirmed: { label: 'Подтверждена', color: 'text-emerald-400 bg-emerald-500/10 border border-emerald-500/30', dot: 'bg-emerald-400' },
  completed: { label: 'Выполнена', color: 'text-zinc-400 bg-zinc-500/10 border border-zinc-500/30', dot: 'bg-zinc-400' },
  cancelled: { label: 'Отменена', color: 'text-red-400 bg-red-500/10 border border-red-500/30', dot: 'bg-red-400' },
};

export const STATUS_ORDER: Array<'new' | 'confirmed' | 'completed' | 'cancelled'> = [
  'new', 'confirmed', 'completed', 'cancelled',
];
