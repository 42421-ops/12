import { motion } from 'framer-motion';
import { Zap, Sparkles, Droplets, CircleDot, Shield, Clock, Wallet } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import type { Service } from '@/types';
import { SERVICES } from '@/constants/services';
import { formatPrice, formatDuration } from '@/utils/date';

const ICONS: Record<string, LucideIcon> = {
  Zap,
  Sparkles,
  Droplets,
  CircleDot,
  Shield,
};

interface ServiceListProps {
  selectedId: string | null;
  onSelect: (service: Service) => void;
}

export function ServiceList({ selectedId, onSelect }: ServiceListProps) {
  return (
    <div className="grid gap-3">
      {SERVICES.map((service, idx) => {
        const Icon = ICONS[service.icon] ?? Droplets;
        const isSelected = selectedId === service.id;
        return (
          <motion.button
            key={service.id}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: idx * 0.05 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => onSelect(service)}
            className={`relative text-left rounded-2xl p-4 transition-all duration-200 ${
              isSelected
                ? 'glass-strong border-accent-cyan/50 shadow-glow'
                : 'glass hover:bg-white/[0.06]'
            }`}
          >
            <div className="flex items-start gap-4">
              <div
                className={`h-12 w-12 rounded-xl flex items-center justify-center shrink-0 transition-all ${
                  isSelected
                    ? 'bg-accent-gradient text-[#0A0A0B]'
                    : 'bg-white/5 text-accent-cyan'
                }`}
              >
                <Icon className="h-6 w-6" />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="font-semibold text-sm leading-tight">{service.name}</h4>
                <p className="text-xs text-zinc-400 mt-1 leading-snug line-clamp-2">
                  {service.description}
                </p>
                <div className="flex items-center gap-4 mt-3">
                  <span className="flex items-center gap-1.5 text-xs text-zinc-300">
                    <Wallet className="h-3.5 w-3.5 text-accent-green" />
                    {formatPrice(service.price)}
                  </span>
                  <span className="flex items-center gap-1.5 text-xs text-zinc-400">
                    <Clock className="h-3.5 w-3.5" />
                    {formatDuration(service.duration)}
                  </span>
                </div>
              </div>
              {isSelected && (
                <motion.div
                  layoutId="serviceCheck"
                  className="absolute top-3 right-3"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: 'spring', duration: 0.3 }}
                >
                  <div className="h-6 w-6 rounded-full bg-accent-gradient flex items-center justify-center">
                    <svg className="h-3.5 w-3.5 text-[#0A0A0B]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M20 6 9 17l-5-5" />
                    </svg>
                  </div>
                </motion.div>
              )}
            </div>
          </motion.button>
        );
      })}
    </div>
  );
}
