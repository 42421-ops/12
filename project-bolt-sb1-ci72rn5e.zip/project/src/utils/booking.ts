import { format } from 'date-fns';

interface ICSData {
  title: string;
  description: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  duration: number; // minutes
}

export function generateICS(data: ICSData): string {
  const [y, m, d] = data.date.split('-').map(Number);
  const [hh, mm] = data.time.split(':').map(Number);
  const start = new Date(y, m - 1, d, hh, mm);
  const end = new Date(start.getTime() + data.duration * 60000);

  const fmt = (date: Date) => format(date, "yyyyMMdd'T'HHmmss");
  const now = format(new Date(), "yyyyMMdd'T'HHmmss");

  return [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//AquaPro//Car Wash Booking//RU',
    'BEGIN:VEVENT',
    `UID:${Date.now()}@aquapro`,
    `DTSTAMP:${now}`,
    `DTSTART:${fmt(start)}`,
    `DTEND:${fmt(end)}`,
    `SUMMARY:${data.title}`,
    `DESCRIPTION:${data.description}`,
    'BEGIN:VALARM',
    'TRIGGER:-PT15M',
    'ACTION:DISPLAY',
    'DESCRIPTION:Напоминание о записи на автомойку',
    'END:VALARM',
    'END:VEVENT',
    'END:VCALENDAR',
  ].join('\r\n');
}

export function downloadICS(data: ICSData): void {
  const ics = generateICS(data);
  const blob = new Blob([ics], { type: 'text/calendar;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'aquapro-booking.ics';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export function formatPhoneDisplay(phone: string): string {
  // Convert stored format back to display
  const digits = phone.replace(/\D/g, '');
  if (digits.length === 11 && digits.startsWith('7')) {
    return `+7 (${digits.slice(1, 4)}) ${digits.slice(4, 7)}-${digits.slice(7, 9)}-${digits.slice(9, 11)}`;
  }
  return phone;
}

export function formatPhoneMasked(value: string): string {
  // Extract digits, keep only last 10 (after 7)
  let digits = value.replace(/\D/g, '');
  if (digits.startsWith('8')) digits = '7' + digits.slice(1);
  if (!digits.startsWith('7') && digits.length > 0) digits = '7' + digits;
  digits = digits.slice(0, 11);

  const area = digits.slice(1, 4);
  const part1 = digits.slice(4, 7);
  const part2 = digits.slice(7, 9);
  const part3 = digits.slice(9, 11);

  let result = '+7';
  if (area.length > 0) result += ` (${area}`;
  if (area.length === 3) result += ')';
  if (area.length === 3 && part1.length > 0) result += ` ${part1}`;
  if (part1.length === 3 && part2.length > 0) result += `-${part2}`;
  if (part2.length === 2 && part3.length > 0) result += `-${part3}`;

  return result;
}

export function isPhoneValid(phone: string): boolean {
  const digits = phone.replace(/\D/g, '');
  return digits.length === 11;
}

export function isNameValid(name: string): boolean {
  return name.trim().length >= 2;
}

export function isCarValid(car: string): boolean {
  return car.trim().length >= 2;
}

export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}
