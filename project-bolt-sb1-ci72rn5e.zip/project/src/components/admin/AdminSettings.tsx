import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Bot, MessageCircle, Check, Loader2, Save } from 'lucide-react';
import { useApp } from '@/store/AppContext';
import { sendTelegramNotification } from '@/utils/telegram';

export function AdminSettings() {
  const { telegramSettings, updateTelegramSettings, showToast } = useApp();
  const [token, setToken] = useState(telegramSettings.botToken);
  const [chatId, setChatId] = useState(telegramSettings.chatId);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<'ok' | 'fail' | null>(null);

  const handleSave = () => {
    updateTelegramSettings({ botToken: token.trim(), chatId: chatId.trim() });
    showToast('Настройки сохранены', 'success');
  };

  const handleTest = async () => {
    setTesting(true);
    setTestResult(null);
    const result = await sendTelegramNotification(
      '✅ Тестовое сообщение от AquaPro',
      { botToken: token.trim(), chatId: chatId.trim() },
    );
    setTesting(false);
    setTestResult(result.success ? 'ok' : 'fail');
    showToast(result.text, result.success ? 'success' : 'error');
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4"
    >
      <div className="glass rounded-2xl p-5">
        <div className="flex items-center gap-3 mb-4">
          <div className="h-10 w-10 rounded-xl bg-accent-gradient/20 flex items-center justify-center">
            <Bot className="h-5 w-5 text-accent-cyan" />
          </div>
          <div>
            <h3 className="font-semibold text-sm">Telegram-уведомления</h3>
            <p className="text-xs text-zinc-400">Настройте бота для оповещений о новых записях</p>
          </div>
        </div>

        <div className="space-y-3">
          <div>
            <label className="text-xs text-zinc-400 mb-1.5 block">Bot Token</label>
            <input
              type="text"
              value={token}
              onChange={(e) => setToken(e.target.value)}
              placeholder="123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11"
              className="input-field"
              autoComplete="off"
            />
          </div>
          <div>
            <label className="text-xs text-zinc-400 mb-1.5 block">Chat ID</label>
            <input
              type="text"
              value={chatId}
              onChange={(e) => setChatId(e.target.value)}
              placeholder="123456789"
              className="input-field"
              autoComplete="off"
            />
          </div>
        </div>

        <div className="flex gap-2 mt-4">
          <button onClick={handleSave} className="btn-secondary flex-1 text-xs">
            <Save className="h-3.5 w-3.5" />
            Сохранить
          </button>
          <button
            onClick={handleTest}
            disabled={testing || !token || !chatId}
            className="btn-primary flex-1 text-xs"
          >
            {testing ? (
              <>
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
                Проверка...
              </>
            ) : testResult === 'ok' ? (
              <>
                <Check className="h-3.5 w-3.5" />
                Работает!
              </>
            ) : (
              <>
                <Send className="h-3.5 w-3.5" />
                Проверить
              </>
            )}
          </button>
        </div>

        <AnimatePresence>
          {testResult === 'fail' && (
            <motion.p
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="text-xs text-red-400 mt-3 flex items-center gap-1.5"
            >
              <MessageCircle className="h-3.5 w-3.5" />
              Проверьте токен и Chat ID
            </motion.p>
          )}
        </AnimatePresence>
      </div>

      <div className="glass rounded-2xl p-4">
        <p className="text-xs text-zinc-400 leading-relaxed">
          Создайте бота через <span className="text-accent-cyan font-medium">@BotFather</span>, получите токен.
          Узнайте свой Chat ID через <span className="text-accent-cyan font-medium">@userinfobot</span>.
          Без настроек уведомления работают в режиме симуляции.
        </p>
      </div>
    </motion.div>
  );
}
