import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CalendarDays, TrendingUp, Clock, Settings, Inbox } from 'lucide-react';
import { useApp } from '@/store/AppContext';
import { PinLogin } from '@/components/admin/PinLogin';
import { BookingCard } from '@/components/admin/BookingCard';
import { AdminSettings } from '@/components/admin/AdminSettings';
import { STATUS_LABELS } from '@/constants/services';
import { formatDateISO, parseISODate, formatFullDate, generateTimeSlots } from '@/utils/date';
import type { Booking, BookingStatus } from '@/types';

type AdminTab = 'today' | 'tomorrow' | 'all' | 'byDate' | 'settings';

export function AdminPage() {
  const { bookings, updateBookingStatus, deleteBooking, showToast } = useApp();
  const [authed, setAuthed] = useState(false);
  const [tab, setTab] = useState<AdminTab>('today');
  const [selectedDate, setSelectedDate] = useState<string>(formatDateISO(new Date()));

  const todayISO = formatDateISO(new Date());
  const tomorrowISO = formatDateISO(new Date(Date.now() + 86400000));

  const filtered = useMemo(() => {
    let list = [...bookings].sort((a, b) => {
      // Sort by date+time ascending
      return (a.date + a.time).localeCompare(b.date + b.time);
    });

    if (tab === 'today') {
      list = list.filter((b) => b.date === todayISO);
    } else if (tab === 'tomorrow') {
      list = list.filter((b) => b.date === tomorrowISO);
    } else if (tab === 'byDate') {
      list = list.filter((b) => b.date === selectedDate);
    }
    return list;
  }, [bookings, tab, todayISO, tomorrowISO, selectedDate]);

  // Stats for today
  const todayBookings = useMemo(
    () => bookings.filter((b) => b.date === todayISO && b.status !== 'cancelled'),
    [bookings, todayISO],
  );
  const todayRevenue = todayBookings.reduce((sum, b) => sum + b.servicePrice, 0);
  const totalSlots = generateTimeSlots().length;
  const freeSlots = Math.max(0, totalSlots - todayBookings.length);

  // Group by date for 'all' tab
  const groupedByDate = useMemo(() => {
    const groups: Record<string, Booking[]> = {};
    [...bookings]
      .sort((a, b) => (b.date + b.time).localeCompare(a.date + a.time))
      .forEach((b) => {
        if (!groups[b.date]) groups[b.date] = [];
        groups[b.date].push(b);
      });
    return Object.entries(groups).sort(([a], [b]) => b.localeCompare(a));
  }, [bookings]);

  if (!authed) {
    return <PinLogin onSuccess={() => setAuthed(true)} />;
  }

  const tabs: Array<{ key: AdminTab; label: string }> = [
    { key: 'today', label: 'Сегодня' },
    { key: 'tomorrow', label: 'Завтра' },
    { key: 'all', label: 'Все' },
    { key: 'byDate', label: 'По дате' },
  ];

  const handleStatusChange = (id: string, status: BookingStatus) => {
    updateBookingStatus(id, status);
    showToast(`Статус: ${STATUS_LABELS[status].label}`, 'success');
  };

  const handleDelete = (id: string) => {
    deleteBooking(id);
    showToast('Запись удалена', 'info');
  };

  return (
    <div className="max-w-md mx-auto px-4 pb-32 pt-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-5">
        <h1 className="text-xl font-bold tracking-tight">Админ-панель</h1>
        <button
          onClick={() => setTab('settings')}
          className={`p-2.5 rounded-xl transition-colors ${tab === 'settings' ? 'bg-accent-gradient/20 text-accent-cyan' : 'glass text-zinc-400 hover:text-zinc-200'}`}
        >
          <Settings className="h-5 w-5" />
        </button>
      </div>

      <AnimatePresence mode="wait">
        {tab !== 'settings' ? (
          <motion.div
            key="main"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            {/* Stats */}
            <div className="grid grid-cols-3 gap-2.5 mb-5">
              <StatCard
                icon={CalendarDays}
                label="Сегодня"
                value={String(todayBookings.length)}
                color="text-accent-cyan"
              />
              <StatCard
                icon={TrendingUp}
                label="Выручка"
                value={`${todayRevenue.toLocaleString('ru-RU')} ₽`}
                color="text-accent-green"
              />
              <StatCard
                icon={Clock}
                label="Свободно"
                value={String(freeSlots)}
                color="text-amber-400"
              />
            </div>

            {/* Tabs */}
            <div className="flex gap-1.5 mb-4 glass rounded-2xl p-1">
              {tabs.map((t) => (
                <button
                  key={t.key}
                  onClick={() => setTab(t.key)}
                  className={`flex-1 py-2 rounded-xl text-xs font-medium transition-all ${
                    tab === t.key
                      ? 'bg-accent-gradient text-[#0A0A0B]'
                      : 'text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>

            {/* Date picker for byDate tab */}
            {tab === 'byDate' && (
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-4"
              >
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="input-field"
                />
              </motion.div>
            )}

            {/* Bookings list */}
            {filtered.length === 0 && tab !== 'all' ? (
              <EmptyState />
            ) : tab === 'all' ? (
              groupedByDate.length === 0 ? (
                <EmptyState />
              ) : (
                <div className="space-y-5">
                  {groupedByDate.map(([date, items]) => (
                    <div key={date}>
                      <h3 className="text-xs font-semibold text-zinc-400 uppercase tracking-wide mb-2 px-1">
                        {formatFullDate(parseISODate(date))}
                      </h3>
                      <div className="space-y-2.5">
                        <AnimatePresence>
                          {items.map((booking) => (
                            <BookingCard
                              key={booking.id}
                              booking={booking}
                              onStatusChange={handleStatusChange}
                              onDelete={handleDelete}
                            />
                          ))}
                        </AnimatePresence>
                      </div>
                    </div>
                  ))}
                </div>
              )
            ) : (
              <div className="space-y-2.5">
                <AnimatePresence>
                  {filtered.map((booking) => (
                    <BookingCard
                      key={booking.id}
                      booking={booking}
                      onStatusChange={handleStatusChange}
                      onDelete={handleDelete}
                    />
                  ))}
                </AnimatePresence>
              </div>
            )}
          </motion.div>
        ) : (
          <motion.div
            key="settings"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold">Настройки</h2>
              <button
                onClick={() => setTab('today')}
                className="text-xs text-zinc-400 hover:text-zinc-200 transition-colors"
              >
                ← К записям
              </button>
            </div>
            <AdminSettings />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, color }: { icon: typeof CalendarDays; label: string; value: string; color: string }) {
  return (
    <div className="glass rounded-2xl p-3">
      <Icon className={`h-4 w-4 mb-2 ${color}`} />
      <p className="text-lg font-bold leading-none">{value}</p>
      <p className="text-[10px] text-zinc-500 mt-1">{label}</p>
    </div>
  );
}

function EmptyState() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass rounded-2xl p-10 text-center"
    >
      <div className="h-14 w-14 rounded-2xl bg-white/5 flex items-center justify-center mx-auto mb-4">
        <Inbox className="h-7 w-7 text-zinc-500" />
      </div>
      <p className="text-sm font-medium text-zinc-300">Записей нет</p>
      <p className="text-xs text-zinc-500 mt-1">Здесь появятся новые бронирования</p>
    </motion.div>
  );
}
