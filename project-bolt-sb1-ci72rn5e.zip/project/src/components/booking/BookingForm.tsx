import { useState, useEffect } from 'react';
import { User, Phone, Car, AlertCircle } from 'lucide-react';
import {
  formatPhoneMasked,
  isPhoneValid,
  isNameValid,
  isCarValid,
} from '@/utils/booking';

export interface FormData {
  name: string;
  phone: string;
  car: string;
}

export interface FormErrors {
  name?: string;
  phone?: string;
  car?: string;
}

interface BookingFormProps {
  value: FormData;
  errors: FormErrors;
  onChange: (data: FormData) => void;
  onErrorsChange: (errors: FormErrors) => void;
}

export function BookingForm({ value, errors, onChange, onErrorsChange }: BookingFormProps) {
  const [touched, setTouched] = useState<Record<string, boolean>>({});

  useEffect(() => {
    const newErrors: FormErrors = {};
    if (touched.name && !isNameValid(value.name)) {
      newErrors.name = 'Введите имя (минимум 2 символа)';
    }
    if (touched.phone && !isPhoneValid(value.phone)) {
      newErrors.phone = 'Введите корректный номер телефона';
    }
    if (touched.car && !isCarValid(value.car)) {
      newErrors.car = 'Укажите марку и модель авто';
    }
    onErrorsChange(newErrors);
  }, [value, touched, onErrorsChange]);

  const handleNameChange = (v: string) => onChange({ ...value, name: v });
  const handlePhoneChange = (v: string) => onChange({ ...value, phone: formatPhoneMasked(v) });
  const handleCarChange = (v: string) => onChange({ ...value, car: v });

  return (
    <div className="space-y-3">
      {/* Name */}
      <div>
        <div className="relative">
          <User className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-500 pointer-events-none" />
          <input
            type="text"
            value={value.name}
            onChange={(e) => handleNameChange(e.target.value)}
            onBlur={() => setTouched((p) => ({ ...p, name: true }))}
            placeholder="Ваше имя"
            className={`input-field pl-11 ${errors.name ? 'error' : ''}`}
          />
        </div>
        {errors.name && (
          <p className="flex items-center gap-1.5 mt-1.5 ml-1 text-xs text-red-400">
            <AlertCircle className="h-3.5 w-3.5" />
            {errors.name}
          </p>
        )}
      </div>

      {/* Phone */}
      <div>
        <div className="relative">
          <Phone className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-500 pointer-events-none" />
          <input
            type="tel"
            inputMode="numeric"
            value={value.phone}
            onChange={(e) => handlePhoneChange(e.target.value)}
            onBlur={() => setTouched((p) => ({ ...p, phone: true }))}
            placeholder="+7 (___) ___-__-__"
            className={`input-field pl-11 ${errors.phone ? 'error' : ''}`}
          />
        </div>
        {errors.phone && (
          <p className="flex items-center gap-1.5 mt-1.5 ml-1 text-xs text-red-400">
            <AlertCircle className="h-3.5 w-3.5" />
            {errors.phone}
          </p>
        )}
      </div>

      {/* Car */}
      <div>
        <div className="relative">
          <Car className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-500 pointer-events-none" />
          <input
            type="text"
            value={value.car}
            onChange={(e) => handleCarChange(e.target.value)}
            onBlur={() => setTouched((p) => ({ ...p, car: true }))}
            placeholder="Марка и модель (например: BMW X5)"
            className={`input-field pl-11 ${errors.car ? 'error' : ''}`}
          />
        </div>
        {errors.car && (
          <p className="flex items-center gap-1.5 mt-1.5 ml-1 text-xs text-red-400">
            <AlertCircle className="h-3.5 w-3.5" />
            {errors.car}
          </p>
        )}
      </div>
    </div>
  );
}
