import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Droplets, Calendar, Clock, ArrowRight, Loader2, Check } from 'lucide-react';
import type { Service } from '@/types';
import { useApp } from '@/store/AppContext';
import { ServiceList } from '@/components/booking/ServiceList';
import { DatePicker } from '@/components/booking/DatePicker';
import { TimeSlots } from '@/components/booking/TimeSlots';
import { BookingForm, type FormData, type FormErrors } from '@/components/booking/BookingForm';
import { SuccessScreen } from '@/components/booking/SuccessScreen';
import { isPhoneValid, isNameValid, isCarValid, formatPhoneDisplay } from '@/utils/booking';
import { formatPrice, formatDuration, parseISODate, formatFullDate } from '@/utils/date';
import type { Booking } from '@/types';

export function BookingPage() {
  const { bookings, addBooking } = useApp();
  const [step, setStep] = useState<'service' | 'datetime' | 'form' | 'success'>('service');
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [formData, setFormData] = useState<FormData>({ name: '', phone: '', car: '' });
  const [formErrors, setFormErrors] = useState<FormErrors>({});
  const [submitting, setSubmitting] = useState(false);
  const [completedBooking, setCompletedBooking] = useState<Booking | null>(null);

  const activeBookings = useMemo(
    () => bookings.filter((b) => b.status !== 'cancelled'),
    [bookings],
  );

  const handleServiceSelect = (service: Service) => {
    setSelectedService(service);
    setSelectedTime(null);
    setStep('datetime');
  };

  const handleDateSelect = (iso: string) => {
    setSelectedDate(iso);
    setSelectedTime(null);
  };

  const handleContinue = () => {
    setStep('form');
  };

  const handleSubmit = async () => {
    if (!selectedService || !selectedDate || !selectedTime) return;

    // Validate all fields
    const errors: FormErrors = {};
    if (!isNameValid(formData.name)) errors.name = 'Введите имя (минимум 2 символа)';
    if (!isPhoneValid(formData.phone)) errors.phone = 'Введите корректный номер телефона';
    if (!isCarValid(formData.car)) errors.car = 'Укажите марку и модель авто';
    setFormErrors(errors);
    if (Object.keys(errors).length > 0) return;

    setSubmitting(true);
    // Simulate brief async for UX
    await new Promise((r) => setTimeout(r, 600));

    const booking = addBooking({
      serviceId: selectedService.id,
      serviceName: selectedService.name,
      servicePrice: selectedService.price,
      serviceDuration: selectedService.duration,
      date: selectedDate,
      time: selectedTime,
      customerName: formData.name.trim(),
      customerPhone: formData.phone,
      carModel: formData.car.trim(),
    });

    setCompletedBooking(booking);
    setSubmitting(false);
    setStep('success');
  };

  const handleReset = () => {
    setStep('service');
    setSelectedService(null);
    setSelectedDate(null);
    setSelectedTime(null);
    setFormData({ name: '', phone: '', car: '' });
    setFormErrors({});
    setCompletedBooking(null);
  };

  // Success screen
  if (step === 'success' && completedBooking) {
    return <SuccessScreen booking={completedBooking} onDone={handleReset} />;
  }

  return (
    <div className="max-w-md mx-auto px-4 pb-32 pt-6">
      {/* Hero */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="text-center mb-6"
      >
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass text-xs text-zinc-400 mb-4">
          <Droplets className="h-3.5 w-3.5 text-accent-cyan" />
          Премиальная автомойка
        </div>
        <h1 className="text-3xl font-extrabold tracking-tight">
          <span className="text-gradient">AquaPro</span>
        </h1>
        <p className="text-sm text-zinc-400 mt-2 leading-relaxed">
          Безупречная чистота вашего авто — запись за минуту
        </p>
      </motion.div>

      {/* Progress indicator */}
      <div className="flex items-center gap-2 mb-6">
        {(['service', 'datetime', 'form'] as const).map((s, idx) => (
          <div
            key={s}
            className={`h-1 flex-1 rounded-full transition-all duration-300 ${
              step === s || (idx < ['service', 'datetime', 'form'].indexOf(step))
                ? 'bg-accent-gradient'
                : 'bg-white/10'
            }`}
          />
        ))}
      </div>

      <AnimatePresence mode="wait">
        {/* Step 1: Service selection */}
        {step === 'service' && (
          <motion.div
            key="service"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.25 }}
          >
            <h2 className="text-lg font-semibold mb-4">Выберите услугу</h2>
            <ServiceList selectedId={selectedService?.id ?? null} onSelect={handleServiceSelect} />
          </motion.div>
        )}

        {/* Step 2: Date & Time */}
        {step === 'datetime' && selectedService && (
          <motion.div
            key="datetime"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.25 }}
          >
            <button
              onClick={() => setStep('service')}
              className="text-xs text-zinc-400 hover:text-zinc-200 mb-4 flex items-center gap-1 transition-colors"
            >
              ← Назад к услугам
            </button>

            {/* Selected service summary */}
            <div className="glass rounded-2xl p-3 mb-5 flex items-center gap-3">
              <div className="h-10 w-10 rounded-xl bg-accent-gradient/20 flex items-center justify-center shrink-0">
                <Droplets className="h-5 w-5 text-accent-cyan" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold truncate">{selectedService.name}</p>
                <p className="text-xs text-zinc-400">{formatPrice(selectedService.price)} · {formatDuration(selectedService.duration)}</p>
              </div>
            </div>

            <h2 className="text-lg font-semibold mb-3 flex items-center gap-2">
              <Calendar className="h-5 w-5 text-accent-cyan" />
              Выберите дату
            </h2>
            <DatePicker selectedDate={selectedDate} onSelect={handleDateSelect} />

            {selectedDate && (
              <motion.div
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="mt-5"
              >
                <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                  <Clock className="h-4 w-4 text-accent-cyan" />
                  Свободное время — {formatFullDate(parseISODate(selectedDate))}
                </h3>
                <TimeSlots
                  dateISO={selectedDate}
                  bookings={activeBookings}
                  selectedTime={selectedTime}
                  onSelect={setSelectedTime}
                />
              </motion.div>
            )}

            {selectedTime && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="mt-6"
              >
                <button onClick={handleContinue} className="btn-primary w-full">
                  Продолжить
                  <ArrowRight className="h-4 w-4" />
                </button>
              </motion.div>
            )}
          </motion.div>
        )}

        {/* Step 3: Form */}
        {step === 'form' && selectedService && selectedDate && selectedTime && (
          <motion.div
            key="form"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.25 }}
          >
            <button
              onClick={() => setStep('datetime')}
              className="text-xs text-zinc-400 hover:text-zinc-200 mb-4 flex items-center gap-1 transition-colors"
            >
              ← Назад к дате и времени
            </button>

            {/* Summary card */}
            <div className="glass rounded-2xl p-4 mb-5 space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-zinc-400">Услуга</span>
                <span className="font-semibold">{selectedService.name}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-zinc-400">Дата</span>
                <span className="font-medium">{formatFullDate(parseISODate(selectedDate))}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-zinc-400">Время</span>
                <span className="font-medium">{selectedTime}</span>
              </div>
              <div className="flex items-center justify-between text-sm pt-2 border-t border-white/10">
                <span className="text-zinc-400">К оплате</span>
                <span className="text-lg font-bold text-gradient">{formatPrice(selectedService.price)}</span>
              </div>
            </div>

            <h2 className="text-lg font-semibold mb-4">Ваши данные</h2>
            <BookingForm
              value={formData}
              errors={formErrors}
              onChange={setFormData}
              onErrorsChange={setFormErrors}
            />

            <button
              onClick={handleSubmit}
              disabled={submitting}
              className="btn-primary w-full mt-5"
            >
              {submitting ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Записываем...
                </>
              ) : (
                <>
                  <Check className="h-4 w-4" />
                  Записаться
                </>
              )}
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
