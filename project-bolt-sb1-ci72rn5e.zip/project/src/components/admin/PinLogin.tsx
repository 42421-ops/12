import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Lock, Delete } from 'lucide-react';
import { ADMIN_PIN } from '@/constants/services';

interface PinLoginProps {
  onSuccess: () => void;
}

export function PinLogin({ onSuccess }: PinLoginProps) {
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const handleDigit = (digit: string) => {
    if (pin.length >= 4) return;
    const newPin = pin + digit;
    setPin(newPin);
    setError(false);

    if (newPin.length === 4) {
      setTimeout(() => {
        if (newPin === ADMIN_PIN) {
          onSuccess();
        } else {
          setError(true);
          setTimeout(() => setPin(''), 600);
        }
      }, 150);
    }
  };

  const handleDelete = () => {
    setPin((p) => p.slice(0, -1));
    setError(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="max-w-xs mx-auto px-4 pt-16 pb-32 flex flex-col items-center"
    >
      <div className="h-16 w-16 rounded-3xl bg-accent-gradient/20 flex items-center justify-center mb-6">
        <Lock className="h-8 w-8 text-accent-cyan" />
      </div>
      <h2 className="text-xl font-bold tracking-tight mb-2">Админ-панель</h2>
      <p className="text-sm text-zinc-400 mb-8 text-center">Введите пин-код для входа</p>

      {/* PIN dots */}
      <div className={`flex gap-3 mb-8 ${error ? 'animate-pulse' : ''}`}>
        {[0, 1, 2, 3].map((i) => (
          <motion.div
            key={i}
            animate={error ? { x: [0, -8, 8, -4, 0] } : {}}
            transition={{ duration: 0.4 }}
            className={`h-4 w-4 rounded-full border-2 transition-all ${
              error
                ? 'border-red-500 bg-red-500/30'
                : i < pin.length
                  ? 'border-accent-cyan bg-accent-cyan'
                  : 'border-white/20'
            }`}
          />
        ))}
      </div>

      {error && (
        <AnimatePresence>
          <motion.p
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="text-sm text-red-400 mb-4"
          >
            Неверный пин-код
          </motion.p>
        </AnimatePresence>
      )}

      {/* Hidden input for mobile keyboard */}
      <input
        ref={inputRef}
        type="tel"
        inputMode="numeric"
        value={pin}
        onChange={(e) => {
          const val = e.target.value.replace(/\D/g, '').slice(0, 4);
          setPin(val);
          setError(false);
          if (val.length === 4) {
            setTimeout(() => {
              if (val === ADMIN_PIN) onSuccess();
              else {
                setError(true);
                setTimeout(() => setPin(''), 600);
              }
            }, 150);
          }
        }}
        className="sr-only"
        aria-hidden
      />

      {/* Keypad */}
      <div className="grid grid-cols-3 gap-3">
        {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((d) => (
          <motion.button
            key={d}
            whileTap={{ scale: 0.92 }}
            onClick={() => handleDigit(d)}
            className="h-16 w-16 rounded-2xl glass text-xl font-semibold text-zinc-100 hover:bg-white/10 transition-colors"
          >
            {d}
          </motion.button>
        ))}
        <div className="h-16 w-16" />
        <motion.button
          whileTap={{ scale: 0.92 }}
          onClick={() => handleDigit('0')}
          className="h-16 w-16 rounded-2xl glass text-xl font-semibold text-zinc-100 hover:bg-white/10 transition-colors"
        >
          0
        </motion.button>
        <motion.button
          whileTap={{ scale: 0.92 }}
          onClick={handleDelete}
          disabled={pin.length === 0}
          className="h-16 w-16 rounded-2xl flex items-center justify-center text-zinc-400 hover:bg-white/10 transition-colors disabled:opacity-30"
        >
          <Delete className="h-6 w-6" />
        </motion.button>
      </div>
    </motion.div>
  );
}
