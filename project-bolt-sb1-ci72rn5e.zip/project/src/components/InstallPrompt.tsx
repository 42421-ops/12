import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Download, X } from 'lucide-react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

export function InstallPrompt() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [dismissed, setDismissed] = useState(() => {
    try {
      return localStorage.getItem('aquapro_install_dismissed') === '1';
    } catch {
      return false;
    }
  });

  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;
    await deferredPrompt.prompt();
    await deferredPrompt.userChoice;
    setDeferredPrompt(null);
  };

  const handleDismiss = () => {
    setDismissed(true);
    try {
      localStorage.setItem('aquapro_install_dismissed', '1');
    } catch {
      // ignore
    }
  };

  const canShow = deferredPrompt && !dismissed;

  return (
    <AnimatePresence>
      {canShow && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
          className="fixed top-[calc(env(safe-area-inset-top)+12px)] left-0 right-0 z-[80] px-4"
        >
          <div className="mx-auto max-w-md glass-strong rounded-2xl p-4 shadow-2xl flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-accent-gradient flex items-center justify-center shrink-0">
              <Download className="h-5 w-5 text-[#0A0A0B]" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold leading-tight">Установите приложение</p>
              <p className="text-xs text-zinc-400 leading-tight mt-0.5">
                Добавьте на главный экран для быстрого доступа
              </p>
            </div>
            <button
              onClick={handleInstall}
              className="shrink-0 px-4 py-2 rounded-xl bg-accent-gradient text-[#0A0A0B] text-xs font-semibold hover:scale-105 transition-transform"
            >
              Установить
            </button>
            <button
              onClick={handleDismiss}
              className="shrink-0 p-1.5 rounded-lg hover:bg-white/10 transition-colors"
            >
              <X className="h-4 w-4 text-zinc-400" />
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
