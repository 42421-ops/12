export type BookingStatus = 'new' | 'confirmed' | 'completed' | 'cancelled';

export interface Service {
  id: string;
  name: string;
  description: string;
  price: number;
  duration: number; // in minutes
  icon: string; // lucide icon name
}

export interface Booking {
  id: string;
  serviceId: string;
  serviceName: string;
  servicePrice: number;
  serviceDuration: number;
  date: string; // ISO date string (YYYY-MM-DD)
  time: string; // HH:mm
  customerName: string;
  customerPhone: string;
  carModel: string;
  status: BookingStatus;
  createdAt: string; // ISO string
}

export interface TelegramSettings {
  botToken: string;
  chatId: string;
}

export type Theme = 'dark' | 'light';

export type TabKey = 'booking' | 'records' | 'admin';

export interface Toast {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
}
