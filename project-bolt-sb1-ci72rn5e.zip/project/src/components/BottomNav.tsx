import { Droplets, CalendarClock, ShieldCheck } from 'lucide-react';
import { motion } from 'framer-motion';
import type { TabKey } from '@/types';

interface BottomNavProps {
  activeTab: TabKey;
  onTabChange: (tab: TabKey) => void;
}

const TABS: Array<{ key: TabKey; label: string; icon: typeof Droplets }> = [
  { key: 'booking', label: 'Услуги', icon: Droplets },
  { key: 'records', label: 'Мои записи', icon: CalendarClock },
  { key: 'admin', label: 'Админ', icon: ShieldCheck },
];

export function BottomNav({ activeTab, onTabChange }: BottomNavProps) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 safe-bottom">
      <div className="mx-auto max-w-md px-4 pb-2">
        <div className="glass-strong rounded-2xl flex items-center justify-around p-1.5 shadow-2xl">
          {TABS.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.key;
            return (
              <button
                key={tab.key}
                onClick={() => onTabChange(tab.key)}
                className="relative flex flex-col items-center gap-1 px-5 py-2.5 rounded-xl min-w-[64px] transition-colors"
              >
                {isActive && (
                  <motion.div
                    layoutId="activeTab"
                    className="absolute inset-0 rounded-xl bg-accent-gradient/15 border border-accent-cyan/30"
                    transition={{ type: 'spring', duration: 0.4 }}
                  />
                )}
                <Icon
                  className={`h-5 w-5 relative z-10 transition-colors ${
                    isActive ? 'text-accent-cyan' : 'text-zinc-500'
                  }`}
                />
                <span
                  className={`text-[10px] font-medium relative z-10 transition-colors ${
                    isActive ? 'text-accent-cyan' : 'text-zinc-500'
                  }`}
                >
                  {tab.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
