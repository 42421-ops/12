import { useState } from 'react';
import { AppProvider } from '@/store/AppContext';
import { Background } from '@/components/Background';
import { BottomNav } from '@/components/BottomNav';
import { ThemeToggle } from '@/components/ThemeToggle';
import { ToastContainer } from '@/components/Toast';
import { InstallPrompt } from '@/components/InstallPrompt';
import { BookingPage } from '@/pages/BookingPage';
import { RecordsPage } from '@/pages/RecordsPage';
import { AdminPage } from '@/pages/AdminPage';
import type { TabKey } from '@/types';

function AppContent() {
  const [tab, setTab] = useState<TabKey>('booking');

  return (
    <div className="min-h-screen relative">
      <Background />

      {/* Top bar */}
      <header className="sticky top-0 z-40 safe-top">
        <div className="mx-auto max-w-md px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="h-7 w-7 rounded-lg bg-accent-gradient flex items-center justify-center">
              <svg viewBox="0 0 24 24" className="h-4 w-4 text-[#0A0A0B]" fill="currentColor">
                <path d="M12 2C7 2 3 9 3 14a6 6 0 0012 0 6 6 0 0012 0c0-5-4-12-9-12z" opacity="0.9"/>
              </svg>
            </div>
            <span className="font-bold text-sm tracking-tight">AquaPro</span>
          </div>
          <ThemeToggle />
        </div>
      </header>

      <main>
        {tab === 'booking' && <BookingPage />}
        {tab === 'records' && <RecordsPage />}
        {tab === 'admin' && <AdminPage />}
      </main>

      <BottomNav activeTab={tab} onTabChange={setTab} />
      <ToastContainer />
      <InstallPrompt />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
