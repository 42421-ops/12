import { motion } from 'framer-motion';
import { CheckCircle2, Calendar, Clock, Wallet, User, Phone, Car, Share2, Plus } from 'lucide-react';
import type { Booking } from '@/types';
import { formatPrice, formatDuration, parseISODate, formatFullDate } from '@/utils/date';
import { downloadICS, formatPhoneDisplay } from '@/utils/booking';

interface SuccessScreenProps {
  booking: Booking;
  onDone: () => void;
}

export function SuccessScreen({ booking, onDone }: SuccessScreenProps) {
  const handleCalendar = () => {
    downloadICS({
      title: `AquaPro — ${booking.serviceName}`,
      description: `${booking.customerName}, ${booking.carModel}`,
      date: booking.date,
      time: booking.time,
      duration: booking.serviceDuration,
    });
  };

  const handleShare = async () => {
    const text = `Моя запись на автомойку AquaPro:\n${booking.serviceName} — ${formatPrice(booking.servicePrice)}\n${formatFullDate(parseISODate(booking.date))}, ${booking.time}\n${booking.carModel}`;
    if (navigator.share) {
      try {
        await navigator.share({ title: 'AquaPro — запись', text });
      } catch {
        // user cancelled
      }
    } else {
      try {
        await navigator.clipboard.writeText(text);
      } catch {
        // ignore
      }
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="flex flex-col items-center min-h-[60vh] justify-center"
    >
      <motion.div
        initial={{ scale: 0, rotate: -180 }}
        animate={{ scale: 1, rotate: 0 }}
        transition={{ type: 'spring', duration: 0.7, delay: 0.1 }}
        className="relative mb-6"
      >
        <div className="h-24 w-24 rounded-full bg-accent-gradient flex items-center justify-center shadow-glow-lg">
          <CheckCircle2 className="h-12 w-12 text-[#0A0A0B]" strokeWidth={2.5} />
        </div>
        <motion.div
          initial={{ scale: 1, opacity: 0.5 }}
          animate={{ scale: 1.8, opacity: 0 }}
          transition={{ duration: 1.5, repeat: Infinity, delay: 0.5 }}
          className="absolute inset-0 rounded-full border-2 border-accent-cyan"
        />
      </motion.div>

      <motion.h2
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="text-2xl font-bold tracking-tight text-center"
      >
        Вы записаны!
      </motion.h2>
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="text-sm text-zinc-400 text-center mt-2"
      >
        Ждём вас в назначенное время
      </motion.p>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="glass-strong rounded-3xl p-5 w-full max-w-md mt-6"
      >
        <div className="flex items-center gap-3 pb-4 border-b border-white/10">
          <div className="h-10 w-10 rounded-xl bg-accent-gradient/20 flex items-center justify-center">
            <Wallet className="h-5 w-5 text-accent-green" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-semibold">{booking.serviceName}</p>
            <p className="text-xs text-zinc-400">{formatDuration(booking.serviceDuration)}</p>
          </div>
          <span className="text-lg font-bold text-gradient">{formatPrice(booking.servicePrice)}</span>
        </div>

        <div className="space-y-3 pt-4">
          <Row icon={Calendar} label="Дата" value={formatFullDate(parseISODate(booking.date))} />
          <Row icon={Clock} label="Время" value={booking.time} />
          <Row icon={User} label="Имя" value={booking.customerName} />
          <Row icon={Phone} label="Телефон" value={formatPhoneDisplay(booking.customerPhone)} />
          <Row icon={Car} label="Авто" value={booking.carModel} />
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="flex gap-3 w-full max-w-md mt-6"
      >
        <button onClick={handleCalendar} className="btn-secondary flex-1">
          <Plus className="h-4 w-4" />
          В календарь
        </button>
        <button onClick={handleShare} className="btn-secondary flex-1">
          <Share2 className="h-4 w-4" />
          Поделиться
        </button>
      </motion.div>

      <motion.button
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.7 }}
        onClick={onDone}
        className="btn-primary mt-4 w-full max-w-md"
      >
        Готово
      </motion.button>
    </motion.div>
  );
}

function Row({ icon: Icon, label, value }: { icon: typeof Calendar; label: string; value: string }) {
  return (
    <div className="flex items-center gap-3">
      <div className="h-8 w-8 rounded-lg bg-white/5 flex items-center justify-center shrink-0">
        <Icon className="h-4 w-4 text-accent-cyan" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-[10px] text-zinc-500 uppercase tracking-wide">{label}</p>
        <p className="text-sm font-medium truncate">{value}</p>
      </div>
    </div>
  );
}
