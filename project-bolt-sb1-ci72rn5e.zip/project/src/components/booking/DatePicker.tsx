import { useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { getNextDays, formatDateLabel, getDayShort, getDayNumber, formatDateISO } from '@/utils/date';
import { DAYS_AHEAD } from '@/constants/services';
import { isToday } from 'date-fns';

interface DatePickerProps {
  selectedDate: string | null;
  onSelect: (dateISO: string) => void;
}

export function DatePicker({ selectedDate, onSelect }: DatePickerProps) {
  const days = getNextDays(DAYS_AHEAD);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to selected date
  useEffect(() => {
    if (selectedDate && scrollRef.current) {
      const el = scrollRef.current.querySelector(`[data-date="${selectedDate}"]`);
      el?.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
    }
  }, [selectedDate]);

  return (
    <div
      ref={scrollRef}
      className="flex gap-2.5 overflow-x-auto no-scrollbar pb-2 -mx-1 px-1"
    >
      {days.map((date) => {
        const iso = formatDateISO(date);
        const isSelected = selectedDate === iso;
        const today = isToday(date);
        return (
          <motion.button
            key={iso}
            whileTap={{ scale: 0.95 }}
            data-date={iso}
            onClick={() => onSelect(iso)}
            className={`shrink-0 flex flex-col items-center justify-center gap-1 rounded-2xl px-4 py-3 min-w-[68px] transition-all ${
              isSelected
                ? 'bg-accent-gradient text-[#0A0A0B] shadow-glow'
                : 'glass hover:bg-white/[0.08]'
            }`}
          >
            <span className={`text-[10px] font-medium uppercase ${isSelected ? 'text-[#0A0A0B]/70' : 'text-zinc-500'}`}>
              {getDayShort(date)}
            </span>
            <span className={`text-lg font-bold leading-none ${isSelected ? 'text-[#0A0A0B]' : 'text-zinc-200'}`}>
              {getDayNumber(date)}
            </span>
            <span className={`text-[10px] font-medium ${isSelected ? 'text-[#0A0A0B]/70' : today ? 'text-accent-cyan' : 'text-zinc-500'}`}>
              {formatDateLabel(date)}
            </span>
          </motion.button>
        );
      })}
    </div>
  );
}
