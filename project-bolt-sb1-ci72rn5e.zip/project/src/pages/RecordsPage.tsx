import { useMemo } from 'react';
import { motion } from 'framer-motion';
import { CalendarClock, Phone, Car, Clock, Calendar, Inbox } from 'lucide-react';
import { useApp } from '@/store/AppContext';
import { STATUS_LABELS } from '@/constants/services';
import { formatPhoneDisplay } from '@/utils/booking';
import { parseISODate, formatFullDate, formatPrice } from '@/utils/date';

export function RecordsPage() {
  const { bookings } = useApp();

  const myBookings = useMemo(
    () =>
      [...bookings]
        .filter((b) => b.status !== 'cancelled')
        .sort((a, b) => (b.date + b.time).localeCompare(a.date + a.time)),
    [bookings],
  );

  return (
    <div className="max-w-md mx-auto px-4 pb-32 pt-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
        <div className="flex items-center gap-3 mb-5">
          <div className="h-10 w-10 rounded-xl bg-accent-gradient/20 flex items-center justify-center">
            <CalendarClock className="h-5 w-5 text-accent-cyan" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight">Мои записи</h1>
            <p className="text-xs text-zinc-400">{myBookings.length} активных</p>
          </div>
        </div>

        {myBookings.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass rounded-2xl p-10 text-center"
          >
            <div className="h-14 w-14 rounded-2xl bg-white/5 flex items-center justify-center mx-auto mb-4">
              <Inbox className="h-7 w-7 text-zinc-500" />
            </div>
            <p className="text-sm font-medium text-zinc-300">Записей пока нет</p>
            <p className="text-xs text-zinc-500 mt-1">Перейдите во вкладку «Услуги» для записи</p>
          </motion.div>
        ) : (
          <div className="space-y-3">
            {myBookings.map((booking, idx) => {
              const status = STATUS_LABELS[booking.status];
              return (
                <motion.div
                  key={booking.id}
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: idx * 0.05 }}
                  className="glass rounded-2xl p-4"
                >
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className="flex-1 min-w-0">
                      <h4 className="font-semibold text-sm truncate">{booking.serviceName}</h4>
                      <span className="text-gradient font-bold text-lg">{formatPrice(booking.servicePrice)}</span>
                    </div>
                    <span className={`badge ${status.color}`}>
                      <span className={`h-1.5 w-1.5 rounded-full ${status.dot}`} />
                      {status.label}
                    </span>
                  </div>

                  <div className="space-y-2">
                    <Row icon={Calendar} text={formatFullDate(parseISODate(booking.date))} />
                    <Row icon={Clock} text={`${booking.time} · ${booking.customerName}`} />
                    <Row icon={Car} text={booking.carModel} />
                    <a href={`tel:${booking.customerPhone.replace(/\D/g, '')}`} className="block hover:text-accent-cyan transition-colors">
                      <Row icon={Phone} text={formatPhoneDisplay(booking.customerPhone)} />
                    </a>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </motion.div>
    </div>
  );
}

function Row({ icon: Icon, text }: { icon: typeof Calendar; text: string }) {
  return (
    <div className="flex items-center gap-2.5 text-xs text-zinc-400">
      <Icon className="h-3.5 w-3.5 text-zinc-500 shrink-0" />
      <span className="truncate">{text}</span>
    </div>
  );
}
