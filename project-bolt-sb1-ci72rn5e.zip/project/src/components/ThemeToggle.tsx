import { Sun, Moon } from 'lucide-react';
import { motion } from 'framer-motion';
import { useApp } from '@/store/AppContext';

export function ThemeToggle() {
  const { theme, toggleTheme } = useApp();

  return (
    <motion.button
      whileTap={{ scale: 0.9 }}
      onClick={toggleTheme}
      className="relative p-2.5 rounded-xl glass hover:bg-white/10 transition-colors"
      aria-label="Переключить тему"
    >
      <motion.div
        key={theme}
        initial={{ rotate: -90, opacity: 0 }}
        animate={{ rotate: 0, opacity: 1 }}
        transition={{ duration: 0.3 }}
      >
        {theme === 'dark' ? (
          <Sun className="h-5 w-5 text-amber-400" />
        ) : (
          <Moon className="h-5 w-5 text-indigo-400" />
        )}
      </motion.div>
    </motion.button>
  );
}
