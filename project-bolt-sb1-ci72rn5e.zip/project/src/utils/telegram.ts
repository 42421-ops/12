import type { TelegramSettings } from '@/types';

interface TelegramMessage {
  text: string;
  success: boolean;
}

export function formatBookingMessage(data: {
  customerName: string;
  customerPhone: string;
  carModel: string;
  serviceName: string;
  servicePrice: number;
  date: string;
  time: string;
}): string {
  const price = `${data.servicePrice.toLocaleString('ru-RU')} ₽`;
  return [
    '🚗 Новая запись!',
    `👤 Имя: ${data.customerName}`,
    `📞 Телефон: ${data.customerPhone}`,
    `🚙 Авто: ${data.carModel}`,
    `💧 Услуга: ${data.serviceName} (${price})`,
    `🕐 Дата: ${data.date}, ${data.time}`,
  ].join('\n');
}

export async function sendTelegramNotification(
  message: string,
  settings: TelegramSettings,
): Promise<TelegramMessage> {
  if (!settings.botToken || !settings.chatId) {
    return { text: 'Симуляция: настройте токен бота в админке', success: false };
  }

  try {
    const url = `https://api.telegram.org/bot${settings.botToken}/sendMessage`;
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: settings.chatId,
        text: message,
        parse_mode: 'HTML',
      }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      return { text: `Ошибка Telegram: ${err.description ?? res.statusText}`, success: false };
    }

    return { text: 'Уведомление отправлено владельцу', success: true };
  } catch {
    return { text: 'Не удалось отправить в Telegram — проверьте подключение', success: false };
  }
}
