import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from 'react';
import type { Booking, BookingStatus, TelegramSettings, Theme, Toast } from '@/types';
import { loadJSON, saveJSON, STORAGE } from '@/utils/storage';
import { generateId } from '@/utils/booking';
import { sendTelegramNotification, formatBookingMessage } from '@/utils/telegram';

interface AppContextValue {
  // Bookings
  bookings: Booking[];
  addBooking: (data: Omit<Booking, 'id' | 'status' | 'createdAt'>) => Booking;
  updateBookingStatus: (id: string, status: BookingStatus) => void;
  deleteBooking: (id: string) => void;

  // Telegram settings
  telegramSettings: TelegramSettings;
  updateTelegramSettings: (settings: TelegramSettings) => void;

  // Theme
  theme: Theme;
  toggleTheme: () => void;

  // Toasts
  toasts: Toast[];
  showToast: (message: string, type?: Toast['type']) => void;
  dismissToast: (id: string) => void;
}

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [bookings, setBookings] = useState<Booking[]>(() => loadJSON(STORAGE.bookings, []));
  const [telegramSettings, setTelegramSettings] = useState<TelegramSettings>(() =>
    loadJSON(STORAGE.telegram, { botToken: '', chatId: '' }),
  );
  const [theme, setTheme] = useState<Theme>(() => loadJSON(STORAGE.theme, 'dark'));
  const [toasts, setToasts] = useState<Toast[]>([]);

  // Persist to localStorage on changes
  useEffect(() => saveJSON(STORAGE.bookings, bookings), [bookings]);
  useEffect(() => saveJSON(STORAGE.telegram, telegramSettings), [telegramSettings]);
  useEffect(() => saveJSON(STORAGE.theme, theme), [theme]);

  // Apply theme to document
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'light') {
      root.classList.remove('dark');
      root.classList.add('light');
    } else {
      root.classList.remove('light');
      root.classList.add('dark');
    }
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', theme === 'dark' ? '#0A0A0B' : '#F9FAFB');
  }, [theme]);

  const showToast = useCallback((message: string, type: Toast['type'] = 'success') => {
    const id = generateId();
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const toggleTheme = useCallback(() => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  }, []);

  const addBooking = useCallback(
    (data: Omit<Booking, 'id' | 'status' | 'createdAt'>): Booking => {
      const booking: Booking = {
        ...data,
        id: generateId(),
        status: 'new',
        createdAt: new Date().toISOString(),
      };
      setBookings((prev) => [...prev, booking]);

      // Fire and forget Telegram notification
      const msg = formatBookingMessage({
        customerName: booking.customerName,
        customerPhone: booking.customerPhone,
        carModel: booking.carModel,
        serviceName: booking.serviceName,
        servicePrice: booking.servicePrice,
        date: booking.date,
        time: booking.time,
      });
      sendTelegramNotification(msg, telegramSettings).then((result) => {
        showToast(result.text, result.success ? 'success' : 'info');
      });

      return booking;
    },
    [telegramSettings, showToast],
  );

  const updateBookingStatus = useCallback((id: string, status: BookingStatus) => {
    setBookings((prev) => prev.map((b) => (b.id === id ? { ...b, status } : b)));
  }, []);

  const deleteBooking = useCallback((id: string) => {
    setBookings((prev) => prev.filter((b) => b.id !== id));
  }, []);

  const updateTelegramSettings = useCallback((settings: TelegramSettings) => {
    setTelegramSettings(settings);
  }, []);

  return (
    <AppContext.Provider
      value={{
        bookings,
        addBooking,
        updateBookingStatus,
        deleteBooking,
        telegramSettings,
        updateTelegramSettings,
        theme,
        toggleTheme,
        toasts,
        showToast,
        dismissToast,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
